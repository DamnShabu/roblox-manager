# Handoff: Roblox Manager redesign

## Overview
This is a redesign of the Roblox Manager desktop app's main window. The app handles multi-account launching and input macros. The window has four parts:
- a title bar with a live status pill
- a game picker
- an accounts list (the first selected account is the group leader)
- a macros panel
There is also a sticky action bar with the launch and stop buttons, and an **Add account** modal that uses Roblox Quick Login (cross-device login code).

## About the design files
The files in this bundle are **design references built in HTML**. They are prototypes that show the intended look and behavior, not production code to copy. Recreate the design in the existing app's codebase, using its framework, component patterns and libraries. Keep all existing backend logic: launching, the Roblox API, cookie storage and macro execution. The prototype only fakes those parts.

## Fidelity
**High-fidelity.** Colors, typography, spacing, states and copy are final. Recreate them pixel-accurately with the codebase's own UI primitives.

## Fonts
- UI: **Source Sans 3** (400/500/600/700), with system-ui as the fallback
- Monospace (usernames, codes, hotkeys, log): **JetBrains Mono** (400/500)
- Base text color: `#efe6d6`. Page background behind the window: `#16130e`.

---

## Screen 1: Main window

### Window
- max-width 1320px, background `#211c15`, border 1px `#3a3124`, radius 14px, shadow `0 30px 80px rgba(0,0,0,.5)`, overflow hidden
- Column flex, from top to bottom: Title bar → Body → Action bar

### Title bar
- height 48px, padding 0 16px, gap 12px, background `#1d1812`, border-bottom 1px `#332b1f`
- Logo tile: 22×22, radius 6, background `#e9bd6a`, letter "R" 13px/700 `#2a1f0c`
- Title "Roblox Manager": 15px/600, letter-spacing .01em
- Status pill: padding 3px 10px, radius 999, background `#2b2419`, 12px `#b9ab93`. It has a 6px dot: `#8fd18a` when any client is running, `#7d715d` when idle. Text is "N running" or "All idle".
- A spacer pushes the remaining items right:
  - **+ Add account**: h30, padding 0 12, radius 7, border 1px `#3a3124`, transparent, 13px `#d8ccb6`, hover background `#2b2419`. Opens the Add account modal.
  - Refresh ↻: 30×30, radius 7, 16px `#9c8f78`, hover background `#2b2419` with text `#efe6d6`
  - Close ✕: 30×30, radius 7, 15px `#9c8f78`, hover background `#4a2420` with text `#ffb3a6`

### Body
- `display:flex; flex-wrap:wrap`. The layout is responsive: the macros column wraps below when the window is narrow.
- Left column: `flex: 999 1 520px`, padding 24px 28px, column gap 28px, border-right 1px `#332b1f`
- Right column (Macros): `flex: 1 1 340px`, padding 24px, column gap 14px, background `#1f1a13`

**Section header pattern** (flex, baseline-aligned, gap 12)
- Label: 12px/600, letter-spacing .12em, uppercase, `#e9bd6a`. The three labels are "01 · Game", "02 · Accounts" and "03 · Macros".
- Helper text: 14px `#9c8f78`

### 01 · Game
- Helper: "Leader's favourites, or open the games browser"
- Tiles sit in a wrapping flex row with gap 14
- Tile (a button):
  - width 124, padding 8, radius 12, column gap 8
  - border 1.5px: `#e9bd6a` when selected, otherwise `#332b1f` (hover `#6b5a3e`)
  - background: `#2e2619` when selected, otherwise `#26201a`
  - Thumbnail: 1:1, radius 8. Use the game's icon; the Games browser tile has its own icon.
  - Name: 13px/500, single line with ellipsis
- Contents: a "Games browser" tile first, then the leader account's favourite games. The prototype uses "[🔥LEOPARD🐆] Grand Piece" and "Grand Blue [Event]". These names were guessed from truncated text, so use real data.
- Single selection. The selected game is the launch target.

### 02 · Accounts
- Helper: "First selected account leads the group". A "Select all" / "Deselect all" text button sits at the right: 13px `#b9ab93`, padding 4px 6px, radius 6, hover `#efe6d6` on `#2b2419`.
- Table: border 1px `#332b1f`, radius 12, overflow hidden
- Grid columns: `40px minmax(0,1fr) auto 76px`
- Header row: padding 8px 14px, background `#1d1812`, 11px uppercase, letter-spacing .08em, `#7d715d`. Columns: (blank), "Account", "Status", "Actions" (right-aligned).
- Account row: padding 12px 14px, border-top 1px `#2e271c`. Background is `#28221a` when selected, `#221d16` otherwise.
  - Checkbox: 22×22, radius 6, border 1.5px. Checked: border and fill `#e9bd6a` with a "✓" at 13px/700 `#2a1f0c`. Unchecked: border `#4a3f2e`, transparent.
  - Name: 15px/600, ellipsis. After the name comes one badge:
    - Leader badge: "Leader", 11px/600, padding 1px 7px, radius 999, background `#4a3a1c`, text `#f0c779`. Shown on the first selected account.
    - Order pill: "#2", "#3"… for the other selected accounts. 11px, background `#2e271c`, text `#9c8f78`.
  - Sub-line: JetBrains Mono 12px `#8a7c64`, for example "@givemegoodname24 · 12h ago", with ellipsis
  - Status: padding 0 12, a 7px dot followed by 13px text. Colors are `#8fd18a` for "Running" and `#7d715d` for "Idle".
  - Actions (gap 4, right-aligned):
    - Star "Make leader": 30×30, radius 7, 15px. Color is `#e9bd6a` on the leader, `#4f4535` otherwise; hover background `#2e271c`.
    - Play/Stop: 30×30, radius 7, border 1px `#3a3124`, background `#2b2419`, 11px `#efe6d6`, showing "▶" (Launch) or "■" (Stop). Hover background `#3a3124`.

### 03 · Macros (right column)
- Header: the label, then "+ New" on the right. The button is h28, padding 0 10, radius 7, border 1px `#3a3124`, 13px `#d8ccb6`.
- Macro card: radius 12, background `#27211a`. Border 1px: `#6b5a3e` while the macro is running, otherwise `#332b1f`.
  - Header row: padding 12px 14px, gap 10. It has:
    - the name at 15px/600
    - a hotkey chip (for example "F6"): mono 11px, padding 2px 6px, radius 5, border 1px `#3a3124`, `#b9ab93`
    - a chevron ▲/▼ at 12px `#7d715d`
    - an enable switch: 36×20, radius 999, `#e9bd6a` when on and `#3a3124` when off. The 16px knob is `#f7efe0`, positioned at left 18px (on) or 2px (off).
  - Clicking the row (except the switch) expands or collapses the card.
  - Expanded body: padding 0 14px 14px, gap 12
    - Step rows (gap 4): grid `22px 70px 1fr`, gap 8, padding 7px 10px, radius 7, background `#1f1a13`, 13px. Each row has an index ("01", mono 11px `#7d715d`), a type (Key/Wait/Click, `#e9bd6a` 600) and a value (mono 12px `#d8ccb6`).
    - Meta row: 13px `#9c8f78`, "Runs on N selected" on the left and "Loop · until stopped" on the right
    - Buttons (flex, gap 8, each flex 1, h32, radius 7, 13px):
      - "Edit steps": border 1px `#3a3124`, transparent, `#d8ccb6`
      - "▶ Run": `#e9bd6a` with `#2a1f0c` text, 600. While running it becomes "■ Stop" with background `#4a2420` and text `#ffb3a6`.
- Activity (pinned to the bottom of the column):
  - Label "ACTIVITY": 11px, letter-spacing .08em, `#7d715d`
  - Log lines: mono 12px `#9c8f78`, with the time in `#5f5646`. Newest first, maximum 4 lines.

### Action bar
- padding 14px 20px, gap 10, background `#1d1812`, border-top 1px `#332b1f`
- Left: summary text, 14px `#b9ab93`. "4 selected · leader MainAccount", or "No accounts selected".
- Right (all h40, radius 9, 14px):
  - **Stop all**: padding 0 18, border 1px `#5a2b24`, transparent, `#ff9d8c`, 600, hover `#3a1d19`
  - **Launch selected (N)**: padding 0 18, border 1px `#4a3f2e`, background `#2b2419`, `#efe6d6`, 600, hover `#3a3124`
  - **Launch as group →** (primary): padding 0 22, background `#e9bd6a`, `#2a1f0c`, 700, hover `#f2cb80`

---

## Screen 2: Add account modal (Quick Login)

### Overlay
- fixed, inset 0, `rgba(12,9,6,.72)` with `backdrop-filter: blur(6px)`, padding 24, `overflow-y:auto`
- The card is centred with `margin:auto`, so it scrolls on short windows.
- Clicking the overlay closes the modal. Clicks inside the card must not propagate.

### Card
- max-width 480, radius 16, border 1px `#3d3326`
- background `radial-gradient(120% 45% at 50% 0%, #2c2418 0%, #231d15 70%)`
- shadow `inset 0 1px 0 rgba(255,236,200,.06), 0 40px 90px rgba(0,0,0,.65)`

### Header
- padding 18px 22px 2px, gap 14
- Icon tile: 42×42, radius 11, background `#3a2e1a`, border 1px `#5a4724`, a "+" at 22px/600 `#f0c779`
- Title "Add account": 18px/700
- Subtitle "Sign in with Roblox Quick Login": 14px `#9c8f78`
- Close ✕: 30×30, radius 8, hover background `#2e271c`

### Stepper
- The container has padding 16px 22px 4px.
- Each step is a grid `26px 1fr` with column-gap 14.
- Step circle: 26×26, radius 50%, border 1.5px, 12px/700. It has three states:
  - pending: background `#2b2419`, border `#4a3f2e`, number in `#d8ccb6`
  - done: fill and border `#e9bd6a`, "✓" in `#2a1f0c`
  - active (step 3): transparent, border and number `#e9bd6a`
- Connector below circles 1 and 2: 1.5px wide, `#3a3124`, margin 4px 0, filling the height
- Step content: padding 2px 0 18px. The title is 15px/600 and the helper is 13px `#9c8f78`.

1. **Open Quick Login in your browser**
   - Helper: "Use a device where you're already signed in."
   - Row (gap 12, wraps, margin-top 10):
     - Primary button "Open in browser ↗": h38, padding 0 16, radius 9, `#e9bd6a` with `#2a1f0c` text, 14px/700, shadow `0 6px 18px rgba(233,189,106,.18)`, hover `#f2cb80`
     - URL label "roblox.com/crossdevicelogin": mono 12px `#7d715d`
   - The button opens `https://www.roblox.com/crossdevicelogin/ConfirmCode` in the system default browser, then marks step 1 done.
2. **Enter this code**
   - Code card: radius 12, background `#1a1510`, border 1px `#3a3124`, overflow hidden
   - Top row (padding 14px 12px 10px 18px, gap 14):
     - The code in JetBrains Mono 30px/500, letter-spacing .14em, `#f7ecd6`, split into two groups of 3 with a 14px gap, `user-select: all`. It is a read-only display, not an input.
     - **Copy** button: h36, padding 0 14, radius 8, border 1px `#3a3124`, background `#2b2419`, 13px/600 `#d8ccb6`. It copies the code to the clipboard, then shows "✓ Copied" for 1.6s with background `#1f2a1c`, border `#3f5a39` and text `#8fd18a`. The first copy marks step 2 done.
   - Expiry row (padding 0 12px 10px 18px, 12px `#7d715d`):
     - Left: "Expires in m:ss" in mono
     - Right: "↻ New code" text button, `#b9ab93`, which requests a fresh code
   - Expiry bar at the bottom edge of the card:
     - 3px track in `#2b2419`
     - The fill width is remaining time ÷ total time, with `transition: width 1s linear`.
     - Fill color is `#e9bd6a`, or `#ff9d8c` under 60 seconds.
   - When the code expires, request a new one automatically.
3. **Approve the sign-in**
   - Helper: "The account shows up in your list automatically."
   - Status box: margin-top 10, padding 10px 12px, radius 10, background `#2a2217`, border 1px `#3d3120`, 13px `#e9c887`, text "Waiting for approval…"
   - Before the text is a pulsing 8px `#e9bd6a` dot. It has a ring whose keyframes go from `scale(1)` at opacity .6 to `scale(2.8)` at opacity 0, running 1.6s ease-out infinite.

### Footer
- padding 12px 22px, border-top 1px `#332b1f`, background `#1f1a13`, right-aligned
- Cancel: h36, padding 0 16, radius 9, border 1px `#4a3f2e`, background `#2b2419`, 14px/600

**Real implementation:** the code, the expiry and the approval polling must come from the app's existing Quick Login integration. The prototype's random 6-character code and 5-minute timer are mock values. When approval succeeds, close the modal, append the new account to the list and write it to the Activity log. Add an error state (for example an expired or denied code) that uses the same status box with red tones (`#ff9d8c` text on `#3a1d19`).

---

## Interactions and behavior
- **Leader** is the first selected account in list order. The star moves that account to the top of the list and selects it. Order pills (#2, #3…) follow the selection order.
- **Launch selected (N)** launches every selected account into the selected game. **Launch as group** does the same as a group that follows the leader; keep the existing app's semantics. Both mark the launched accounts as Running and add a log line.
- **Per-row ▶ / ■** launches or stops a single account.
- **Stop all** stops every client and every running macro, then logs "Stopped N client(s)".
- **Macros:** a disabled macro cannot run. Turning a macro off also stops it. "+ New" collapses the other macro cards and adds "Macro N" in the expanded state.
- The title-bar pill and the action-bar summary update live.
- **Hover:** every button has the hover state listed above. There are no other animations besides the expiry bar and the pulse.

## State
- `selectedGameId`
- `accountOrder[]` and `selected{id: bool}`, from which the leader is derived
- `running{accountId: bool}`
- `macros[]`: `{id, name, hotkey, enabled, expanded, running, loopMode, steps[{type, value}]}`
- `activityLog[]` (maximum 4 shown)
- Add account modal: `open`, `code`, `expiresAt`, `copied` (transient), `linkOpened`, `codeCopied`, `status` (waiting / approved / error)

## Design tokens
**Surfaces**

| Value | Use |
|---|---|
| `#16130e` | page |
| `#1a1510` | code well |
| `#1d1812` | bars and table header |
| `#1f1a13` | macros column, step rows, modal footer |
| `#211c15` | window |
| `#221d16` | unselected row |
| `#231d15` | modal |
| `#26201a` | tile |
| `#27211a` | macro card |
| `#28221a` | selected row |
| `#2b2419` | control and secondary button |
| `#2e271c` | pill and hover |
| `#3a3124` | hover and strong control |

**Borders:** `#2e271c`, `#332b1f`, `#3a3124`, `#3d3326`, `#4a3f2e`, `#6b5a3e`

**Text**

| Value | Use |
|---|---|
| `#efe6d6` | primary |
| `#f7ecd6` | code |
| `#d8ccb6` | secondary control |
| `#b9ab93` | muted |
| `#9c8f78` | helper |
| `#8a7c64` | mono meta |
| `#7d715d` | labels |
| `#5f5646` | timestamps |

**Accent (amber):** `#e9bd6a`, hover `#f2cb80`. Tints: `#f0c779`, `#e9c887`, `#4a3a1c`, `#3a2e1a`, `#5a4724`. Text on the accent is `#2a1f0c`.

**Success:** `#8fd18a`, `#1f2a1c`, `#3f5a39`

**Danger:** `#ff9d8c`, `#ffb3a6`, `#5a2b24`, `#4a2420`, `#3a1d19`

**Radius:** 5 (chip), 6 (checkbox), 7 (small button), 8, 9 (large button), 10, 11, 12 (card and table), 14 (window), 16 (modal), 999 (pill)

**Type scale:** 11 / 12 / 13 / 14 / 15 / 18 px, plus 30px mono for the code

**Spacing:** 4 / 8 / 10 / 12 / 14 / 18 / 22 / 24 / 28 px

## Assets
- Game thumbnails are striped placeholders in the prototype. Use the real game icons from the Roblox API.
- The icons are Unicode glyphs (✓ ★ ▶ ■ ↻ ✕ ↗ ▲ ▼ +). Swap them for the codebase's icon set if it has one.

## Files
- `Roblox Manager.dc.html`: the full interactive prototype, with both screens. Open it in a browser with `support.js` next to it, and click "+ Add account" to see the modal.
- `support.js`: the prototype runtime (reference only, do not port it).
