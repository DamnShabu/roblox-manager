# Handoff: Roblox Manager (multi-account launcher)

## Overview
Roblox Manager is a desktop app for running and managing many Roblox accounts at
once. From one window a user can launch accounts, join a shared game, run
per-account automation ("macros"), update the Roblox client, organize accounts
into groups, and shut everything (or a whole group) down. This handoff also
includes the launcher app-icon exploration; the chosen mark is **1b — Stacked
accounts**.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes
that show the intended look and behavior. They are **not** production code to
copy directly. The `.dc.html` files use an internal preview runtime
(`support.js`) that is only there so the prototype runs in a browser; it is **not**
part of the deliverable and should not be ported.

The task is to **recreate these designs in the target codebase's existing
environment** (React, Vue, SwiftUI, native desktop, Electron, Tauri, etc.),
following that codebase's established patterns, component library, and state
conventions. If no environment exists yet, choose the most appropriate stack for
a desktop multi-account launcher (an Electron/Tauri + React shell is a natural
fit) and implement there.

Read the HTML for exact markup, colors, spacing, and copy. Treat the logic class
inside each file as a description of intended behavior, not as code to lift.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, icons, and interaction
states are final. Recreate the UI pixel-perfectly using the codebase's own
primitives. Exact hex values and measurements are listed in **Design Tokens**.

## Screens / Views

### 1. Main window (`Roblox Manager v2.dc.html`)
Single-window desktop app. Centered card, `max-width: 1320px`, full-height, dark
theme. Vertical stack: **title bar → body → activity log/footer**.

**Title bar** (height 52px, bg `#1d1812`, bottom border `1px #332b1f`, padding
`0 10px 0 16px`, items in a 12px-gap flex row):
- App icon: 28×28 **Stacked accounts (1b)** SVG mark (see Assets), then bold 15px
  "Roblox Manager".
- Running pill: rounded 999px chip, 24px tall, showing a colored dot + "N
  running" label. Color/label are state-driven (idle vs running).
- Spacer, then action buttons (all 32px tall, radius 8px, 13px/600 labels):
  - **Update Roblox** — min-width 156px. Idle: label + `download`/`sync` icon.
    While updating: swaps to a 64px progress bar + monospace percent readout
    (JetBrains Mono). Border `#3a3124`, states change bg/color.
  - **Add account** — `person_add` icon (icon tint `#e9bd6a`) + label, bg
    `#27211a`, border `#3a3124`; hover bg `#2e271c`, border `#4a3f2e`.
  - 1px divider, then icon-only **Refresh** (`refresh`) and **Close** (`close`,
    hover bg `#4a2420`, color `#ffb3a6`). Icon buttons are 32×32, transparent,
    color `#9c8f78`, hover bg `#2b2419`.

**Body**: a toolbar row (bulk **Launch all** / **Shut down all**, game picker,
search) above the account list. Accounts render as rows; **groups** render as
collapsible sections above/among them.

**Account row**:
- Left: status indicator, account name/username (Source Sans 3), current game +
  state text.
- Right: action buttons — **Settings** (`settings`, 34×34, radius 9px, toggles the
  settings panel), and a **Play/Stop** control. There is intentionally **no**
  auto-join/"make leader" button on the row itself (moved into settings).
- Running accounts show an animated pulse (`@keyframes rmPulse`, scale 1→2.8,
  opacity .6→0).

**Account settings panel** (expands under a row, bg `#1b1611`, top border `1px
#2b2419`, padding `18px 20px 18px 70px`, 18px gap column). Rows use a
`124px minmax(0,1fr)` label/control grid:
- **Notes** — free text, also surfaced on row hover.
- **Session** — refresh session button.
- **Macro** — select which macro this account runs.
- **Low power mode** — toggle.
- **Leader** — a **Make leader** button (`star` outline icon, border `#3a3124`,
  hover border+text `#e9bd6a`). If the account is already leader it instead shows
  a filled gold `star` + "This account is the leader". The leader account's note
  reads "Make another account leader from its settings to hand over the lead."

**Groups**: collapsible section per group, with a game icon + group name and, when
a game is assigned, a game badge beside the name. Header row has a group
**Launch** button that is state-aware:
- No game assigned / empty → disabled look (opacity .4, `not-allowed`).
- Game assigned, nothing live → **Launch** (`play_arrow`, bg `#2b2419`, border
  `#4a3f2e`, text `#efe6d6`) — launches every account in the group into the
  assigned game.
- Any account in the group running or joining → **Shut down** (red: `stop` icon,
  transparent bg, border `#5a2b24`, text `#ff9d8c`) — stops every account in the
  group at once.
- Header also has a **+** to add accounts to the group; accounts can be dragged
  between groups or removed.

**Footer / activity log**: append-only log of actions ("Launched …", "Shut down
…", update progress) with info/success styling.

### 2. Launcher icon exploration (`Launcher Icon.dc.html`)
Three original app-mark candidates built from the tilted, chunky block geometry of
the Roblox logo (each rotated `-14°`). Each is shown large (140px), as a desktop
tile (72px), and at title-bar size (28px).
- **1a — Play block**: single rounded gold square with a play triangle knocked out.
- **1b — Stacked accounts (CHOSEN)**: three offset rounded squares (`#6b5634`,
  `#b08c4c`, `#e9bd6a` front-to-back stacked) with a small dark square hole cut
  from the front square — evokes both the Roblox stud and stacked accounts. This
  is the mark used in the main window title bar.
- **1c — Account grid**: light rounded square holding a 2×2 grid of studs, one
  highlighted.

Ship **1b** as the app icon. Provide it at 16/32/128/256/512 for desktop targets;
the SVG in Assets scales cleanly.

## Interactions & Behavior
- **Launch account/group**: clicking play marks account(s) as joining → running;
  logs the action; running pill count updates. Group button flips to red **Shut
  down** while any member is live.
- **Shut down**: clears running/joining state for the account or every account in
  the group; logs "Shut down …".
- **Update Roblox**: button enters progress mode, animates a percent bar
  (`width` transition `.14s linear`) to 100%, then returns to idle.
- **Settings panel**: toggled per-account by the settings button; only affects
  that row.
- **Groups**: expand/collapse on header click; **+** adds members; drag to move an
  account between groups; assigning a game tags every member visually.
- **Notes on hover**: an account's note shows when hovering its row.
- **Refresh / Refresh session**: re-fetch account/session state.
- **Pulse animation** on active accounts (see keyframes).

## State Management
Per account: `id`, `name`/`username`, `groupId`, `macroId`, `note`,
`lowPower` (bool), `isLeader` (bool). App-level maps: `running` (accountId →
bool), `joining` (accountId → bool), selected game per group, `editGroup`
(currently-open group editor), expanded/collapsed group ids, `editSettings`
(which account's settings panel is open), update progress (`updPct`,
in-progress flag), and an activity `log` array. A group's launch button derives
its mode from whether **any** member id is in `running`/`joining`.

## Design Tokens

**Colors**
- App background: `#16130e`
- Window surface: `#211c15`; title bar / raised surface: `#1d1812`
- Settings panel surface: `#1b1611`; input/inset: `#15110c`
- Button surface: `#27211a` / `#2b2419`; hover `#2e271c` / `#3a3124`
- Borders: `#332b1f`, `#3a3124`, `#4a3f2e`
- Primary text: `#efe6d6`; muted text: `#9c8f78`, `#b9ab93`
- Accent (gold): `#e9bd6a`; link hover `#f5d596`; icon accent `#e9bd6a`
- Gold stack shades (icon 1b): `#6b5634`, `#b08c4c`, `#e9bd6a`
- Positive/running dot: gold; destructive: border `#5a2b24` / `#4a2420`, text
  `#ff9d8c` / `#ffb3a6`
- Badge chip: bg `#3a2e1a`, text `#f0c779`

**Typography**
- UI: **Source Sans 3** (400/500/600/700), fallback `system-ui, sans-serif`
- Monospace (percentages, technical readouts): **JetBrains Mono** (400/500)
- Icons: **Material Symbols Rounded** (opsz 20–48, wght 100–700, FILL 0–1). Fill 1
  for active/emphasis states.
- Common sizes: title 15px/700, body 13–15px, labels 12–13px/600, muted 12–14px.

**Radii**: window/card 16px; buttons 8px; settings buttons 9px; icon tiles 18px;
chips/pills 999px; small studs 2–4px.

**Spacing**: card padding 24px; settings panel `18px 20px 18px 70px`, 18px gap;
title-bar 12px gap; button padding `0 12px 0 10px` (icon+label).

**Shadow**: window `inset 0 1px 0 rgba(255,236,200,.05), 0 30px 80px rgba(0,0,0,.5)`.

**Animation**: `@keyframes rmPulse { 0%{scale 1;opacity .6} 100%{scale 2.8;opacity 0} }`;
update bar `width .14s linear`.

## Assets
- **App icon (1b, ship this):** inline SVG, no external file.
  ```html
  <svg viewBox="0 0 100 100">
    <g transform="rotate(-14 50 50)">
      <rect x="30" y="8"  width="56" height="56" rx="8" fill="#6b5634"/>
      <rect x="22" y="22" width="56" height="56" rx="8" fill="#b08c4c"/>
      <rect x="14" y="36" width="56" height="56" rx="8" fill="#e9bd6a"/>
      <rect x="34" y="56" width="16" height="16" rx="2" fill="#1d1812"/><!-- hole; match bg -->
    </g>
  </svg>
  ```
  The hole fill should match whatever it sits on (title bar `#1d1812`, tile
  `#2a1f0c`, etc.). Icon candidates 1a/1c live in `Launcher Icon.dc.html` for
  reference only.
- **Fonts**: Source Sans 3, JetBrains Mono, Material Symbols Rounded (Google
  Fonts). Bundle locally for a desktop app rather than hot-linking.
- No raster images are used; all UI is CSS + inline SVG + icon font.

## Files
- `Roblox Manager v2.dc.html` — the full app design (main window, groups, per-
  account settings, update flow, activity log). Primary reference.
- `Launcher Icon.dc.html` — app-icon exploration; **1b** is the chosen mark.
- `support.js` — preview runtime only; **do not port**.

Note: `.dc.html` files open in a browser directly if you want to see the designs
live. Ignore the `<x-dc>` / `support.js` scaffolding when implementing — read the
inline styles and copy as the source of truth.
